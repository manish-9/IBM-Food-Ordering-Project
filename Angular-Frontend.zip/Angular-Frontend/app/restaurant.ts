export interface IRestaurant{

    
        restaurantName: string,
        email: string,
        contactNumber: string,
        locality: String,
        password: String
    
}