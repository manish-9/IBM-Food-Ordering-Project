import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-restaurantlogin',
  templateUrl: './restaurantlogin.component.html',
  styleUrls: ['./restaurantlogin.component.css']
})
export class RestaurantloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
