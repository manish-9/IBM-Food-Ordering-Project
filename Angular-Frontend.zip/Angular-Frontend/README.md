# Online-Food-Ordering-Angular-SpringBoot-
Online Food ordering web application made using Spring Boot and Angular. Makes use of MySQL to store app details. 

Swagger2 enables easy testing of backend code.

Uses 'WebStorageService' to keeps track of session details of the users.

